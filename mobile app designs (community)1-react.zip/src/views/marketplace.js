import React from 'react'

import { Helmet } from 'react-helmet'

import './marketplace.css'

const Marketplace = (props) => {
  return (
    <div className="marketplace-container">
      <Helmet>
        <title>exported project</title>
      </Helmet>
      <div className="marketplace-marketplace">
        <img
          src="/playground_assets/untitl12ed13546-ol6i-900h.png"
          alt="untitl12ed13546"
          className="marketplace-untitl12ed1"
        />
        <img
          src="/playground_assets/rectangle403546-pw4.svg"
          alt="Rectangle403546"
          className="marketplace-rectangle40"
        />
        <span className="marketplace-text">
          <span>Market Place</span>
        </span>
        <img
          src="/playground_assets/ellipse53546-b0np-200h.png"
          alt="Ellipse53546"
          className="marketplace-ellipse5"
        />
        <span className="marketplace-text02">
          <span>Home</span>
        </span>
        <img
          src="/playground_assets/rectangle533576-2bnd-500h.png"
          alt="Rectangle533576"
          className="marketplace-rectangle53"
        />
        <div className="marketplace-fdsfds">
          <div className="marketplace-table">
            <div className="marketplace-fdsfds01">
              <div className="marketplace-fdsfds02">
                <div className="marketplace-content">
                  <span className="marketplace-text04">
                    <span>Protein Powder 250g</span>
                  </span>
                </div>
              </div>
              <div className="marketplace-cell">
                <div className="marketplace-contents"></div>
              </div>
            </div>
            <div className="marketplace-fdsfds03">
              <div className="marketplace-cell01">
                <div className="marketplace-content01">
                  <span className="marketplace-text06">
                    <span>Kauai Smoothie Voucher</span>
                  </span>
                </div>
              </div>
              <div className="marketplace-cell02">
                <div className="marketplace-content02">
                  <span className="marketplace-text08">
                    <span>100 Gems</span>
                  </span>
                </div>
              </div>
            </div>
            <div className="marketplace-fdsfds04">
              <div className="marketplace-cell03">
                <div className="marketplace-hi">
                  <span className="marketplace-text10">
                    <span>Free Yoga 1 hour Session</span>
                  </span>
                </div>
              </div>
              <div className="marketplace-hhhh">
                <div className="marketplace-content03">
                  <span className="marketplace-text12">
                    <span>1000 Gems</span>
                  </span>
                </div>
              </div>
            </div>
            <div className="marketplace-fdsfds05">
              <div className="marketplace-cell04">
                <div className="marketplace-content04">
                  <span className="marketplace-text14">
                    <span>Our personalised Meal Planner Book</span>
                  </span>
                </div>
              </div>
              <div className="marketplace-cell05">
                <div className="marketplace-content05">
                  <span className="marketplace-text16">
                    <span>5600 Gems</span>
                  </span>
                </div>
              </div>
            </div>
            <div className="marketplace-fdsfds06">
              <div className="marketplace-cell06">
                <div className="marketplace-content06">
                  <span className="marketplace-text18">
                    <span>R500 Takealot Voucher</span>
                  </span>
                </div>
              </div>
              <div className="marketplace-cell07">
                <div className="marketplace-content07">
                  <span className="marketplace-text20">
                    <span>10000 Gems</span>
                  </span>
                </div>
              </div>
            </div>
            <div className="marketplace-fdsfds07">
              <div className="marketplace-cell08">
                <div className="marketplace-content08">
                  <span className="marketplace-text22"></span>
                </div>
              </div>
              <div className="marketplace-cell09">
                <div className="marketplace-content09">
                  <span className="marketplace-text23"></span>
                </div>
              </div>
            </div>
            <div className="marketplace-fdsfds08">
              <div className="marketplace-cell10">
                <div className="marketplace-content10">
                  <span className="marketplace-text24"></span>
                </div>
              </div>
              <div className="marketplace-cell11">
                <div className="marketplace-content11">
                  <span className="marketplace-text25"></span>
                </div>
              </div>
            </div>
            <div className="marketplace-fdsfds09">
              <div className="marketplace-cell12">
                <div className="marketplace-content12">
                  <span className="marketplace-text26"></span>
                </div>
              </div>
              <div className="marketplace-cell13">
                <div className="marketplace-content13">
                  <span className="marketplace-text27"></span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <img
          src="/playground_assets/rectangle3649-546g-200h.png"
          alt="Rectangle3649"
          className="marketplace-rectangle"
        />
        <span className="marketplace-text28">
          <span>100 gems</span>
        </span>
        <img
          src="/playground_assets/arrow73781-zz4.svg"
          alt="Arrow73781"
          className="marketplace-arrow7"
        />
        <img
          src="/playground_assets/arrow84061-a6i.svg"
          alt="Arrow84061"
          className="marketplace-arrow8"
        />
        <img
          src="/playground_assets/arrow94061-1xfn.svg"
          alt="Arrow94061"
          className="marketplace-arrow9"
        />
        <img
          src="/playground_assets/arrow104061-jfro.svg"
          alt="Arrow104061"
          className="marketplace-arrow10"
        />
        <img
          src="/playground_assets/arrow114061-6joh.svg"
          alt="Arrow114061"
          className="marketplace-arrow11"
        />
        <div className="marketplace-frame1">
          <span className="marketplace-text30">
            <span>Balance: 100</span>
          </span>
        </div>
      </div>
    </div>
  )
}

export default Marketplace
